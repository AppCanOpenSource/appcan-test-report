/*Auto generate by UI designer */
(function($) {
    appcan.button("#nav-left", "btn-act", function() {
    });
    appcan.button("#nav-right", "btn-act", function() {
    });
    appcan.button("#Button_DgxEcP", "btn-act", function() {
        //uexWindow.open('case11', '0', "case/unittest.html", 0, '', '', 0, 500);
        appcan.window.open("case", "case/unittest.html", 1);
    })
})($); 